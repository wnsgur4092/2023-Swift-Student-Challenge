import SwiftUI
import AVFoundation
import UIKit

struct ContentView: View {
    @State private var activeNote : Int? = nil
    var body: some View {
        VStack {
            NumericKeypad(activeNote: $activeNote)
                .padding(.top, 10)
        }
        .padding()
    }
}


struct NumericKeypad: View {
    //PROPERTIES
    let numbers = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"]
    @State var numberArray: [String] = []
    let tune = Tune()
    @Binding var activeNote : Int?
    @State var isPlaying : Bool = false
    @State var currentIndex : Int = 0
    @State var audioPlayers: [AVAudioPlayer] = []
    @State var currentPlay : AVAudioPlayer?
    @State var maxNoteCount : Int = 64
    
    //BODY
    var body: some View {
        VStack(alignment: .leading) {
            VStack(alignment: .leading){
                HStack(spacing: 20) {
                    //EXAMPLE MUSIC
                    Button {
                        addPiDigits()
                    } label: {
                        Text("Pi Song")
                            .foregroundColor(.black)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                            .background(RoundedRectangle(cornerRadius: 22).stroke(Color.yellow))
                    }
                    .disabled(isPlaying)
                    
                    Button {
                        addThreeBears()
                    } label: {
                        Text("Three bears song")
                            .foregroundColor(.black)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                            .background(RoundedRectangle(cornerRadius: 22).stroke(Color.yellow))
                    }
                    .disabled(isPlaying)
                    
                    Button {
                        addPlaneDigit()
                    } label: {
                        Text("Plane in the sky")
                            .foregroundColor(.black)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                            .background(RoundedRectangle(cornerRadius: 22).stroke(Color.yellow))
                    }
                    .disabled(isPlaying)

                    
                    Spacer()
                    
                    //PLAY AND RESET BUTTON
                    
                    //RESET BUTTON
                    VStack(alignment: .center){
                        Button {
                            numberArray = []
                        } label: {
                            Image(systemName: "arrow.uturn.down.square.fill")
                                .resizable()
                                .scaledToFit()
                                .foregroundColor(isPlaying ? .gray : .blue)
                                .frame(width: 44, height: 44)
                        }
                        .disabled(isPlaying)
                        
                        Text("Reset")
                            .font(.callout)
                    }
                    .padding(.trailing, 40)
                    
                    //PLAY BUTTON
                    VStack(alignment: .center){
                        Button {
                            if isPlaying {
                                pauseSound()
                            } else {
                                playSound()
                                print(numberArray)
                            }
                        } label: {
                            Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                                .resizable()
                                .scaledToFit()
                                .foregroundColor(isPlaying ? .red : .green)
                                .frame(width: 44, height: 44)
                        }
                        
                        Text(isPlaying ? "Pause" : "Play")
                    }
                }
                
                Divider()

                
                //INPUT NUMBER SECTION
                VStack(alignment:.leading){
                    Text("Your Numbers")
                        .font(.title2)
                    
                    if numberArray.isEmpty {
                        //PLACEHOLDER
                        VStack(alignment: .leading, spacing: 20){
                            HStack(spacing: 5){
                                Text("Tap numbers below & Click")
                                Image(systemName: "play.fill")
                                    .foregroundColor(.green)
                            }
                            
                            HStack(spacing: 10){
                                Text("Listen to the examples")
                                Text("songs")
                                    .foregroundColor(.gray)
                                    .padding(.horizontal, 20)
                                    .padding(.vertical, 10)
                                    .background(RoundedRectangle(cornerRadius: 22).stroke(Color.yellow))
                                Text("above!")
                            }
                        }
                        .font(.title2)
                        .foregroundColor(.gray)
                        .padding(.top, 20)
                        
                    } else {
                        Text("\(numberArray.joined(separator: " "))")
                            .font(.title2)
                            .padding(.top, 20)
                    }
                }

                
                Spacer()
                
                //WORD NUMBR COUNT
                HStack{
                    Spacer()
                    Text("\(numberArray.count)")
                        .foregroundColor(.blue)
                    Text("/ 64")
                }
            }
            
            Spacer()
            
            Divider()
                .padding(.bottom, 10)
            
            //XYLOPHONE HEAD & DELETE BUTTON
            HStack{
                Spacer()
                
                Button {
                    if !numberArray.isEmpty {
                        numberArray.removeLast()
                    }
                } label: {
                    Image(systemName: "delete.left.fill")
                        .resizable()
                        .foregroundColor(.gray)
                        .frame(width: 55, height: 44)
                }
                .disabled(isPlaying)

            }
            .padding(.bottom, 10)
            
            //XYLOPHONE KEYBOARD
            ZStack{
                HStack(spacing: 10) {
                    ForEach(tune.notes.indices, id: \.self) { index in
                        let buttonHeight = 350 - CGFloat(index) * 16
                        let note = tune.notes[index]
                        Text(String(note.number))
                            .font(.largeTitle)
                            .foregroundColor(.white)
                            .frame(maxWidth:.infinity, maxHeight: buttonHeight)
                            .background(numberArray.count < maxNoteCount ? note.color : .gray)
                            .cornerRadius(10)
                            .shadow(color: .black.opacity(0.3), radius: 2, x: 2, y: 2)
                            .onTapGesture {
                                if numberArray.count < maxNoteCount {
                                    let generator = UIImpactFeedbackGenerator(style: .medium)
                                    generator.prepare()
                                    generator.impactOccurred()
                                    numberArray.append(String(note.number))
                                }
                                
                                if let soundURL = Bundle.main.url(forResource: note.sound, withExtension: nil) {
                                    do {
                                        if numberArray.count < maxNoteCount{
                                            currentPlay = try AVAudioPlayer(contentsOf: soundURL)
                                            currentPlay?.play()
                                        }
                                    } catch {
                                        print("Error playing sound: \(error.localizedDescription)")
                                    }
                                }
                            }
                            .disabled(isPlaying)
                    }
                }
                .zIndex(1)
                
                VStack{
                    Rectangle().fill(Color.brown)
                        .frame(maxWidth: .infinity, maxHeight: 10)
                    
                    Spacer().frame(height: 100)
                    
                    Rectangle().fill(Color.brown)
                        .frame(maxWidth: .infinity, maxHeight: 10)
                }
            }
        }
        .frame(maxWidth: .infinity)
    }
    
    //FUNCTION
    func playSound() {
        isPlaying.toggle()
        
        let soundMap = Dictionary(uniqueKeysWithValues: tune.notes.map { ($0.number, $0.sound) })
        
        func playNextSound(index: Int) {
            if isPlaying && index < numberArray.count {
                if let sound = soundMap[Int(numberArray[index])!] {
                    let url = Bundle.main.url(forResource: sound, withExtension: nil)!
                    let audioPlayer = try? AVAudioPlayer(contentsOf: url)
                    audioPlayer?.prepareToPlay()
                    audioPlayers.append(audioPlayer!)
                    activeNote = Int(numberArray[index])
                    audioPlayer?.play()
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        activeNote = nil
                        playNextSound(index: index + 1)
                    }
                }
            } else {
                isPlaying = false
            }
        }
        playNextSound(index: currentIndex)
    }
    

    func pauseSound() {
        if let audioPlayer = audioPlayers.first {
            audioPlayer.pause()
            currentIndex = max(currentIndex - 1, 0)
            audioPlayer.currentTime = 0
            isPlaying.toggle()
        }
    }
    
    func addPiDigits() {
        let piDigits = "3141592653589793238462643383279502884197169399375105820974944592"
        numberArray = Array(piDigits.prefix(64)).map(String.init)
    }
    
    func addPlaneDigit(){
        let planeDigit = "3212333222333321233322321"
        numberArray = Array(planeDigit.prefix(64)).map(String.init)
    }
    
    func addThreeBears() {
        let threeBearsDigit = "11111355315535531115531555553155555318585321"
        numberArray = Array(threeBearsDigit.prefix(64)).map(String.init)
    }
}

