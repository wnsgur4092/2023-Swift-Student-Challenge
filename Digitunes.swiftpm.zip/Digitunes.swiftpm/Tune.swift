//
//  Tune.swift
//  NumPiano
//
//  Created by JunHyuk Lim on 12/4/2023.
//

import SwiftUI

struct Note {
    let name: String
    let syllable: String
    let sound: String
    let number: Int
    let color : Color 
}

struct Tune {
    let notes: [Note]
    
    init() {
        notes = [
            Note(name: "C", syllable: "do", sound: "1.mp3", number: 1, color: .red),
            Note(name: "D", syllable: "re", sound: "2.mp3", number: 2, color: .orange),
            Note(name: "E", syllable: "mi", sound: "3.mp3", number: 3, color: .yellow),
            Note(name: "F", syllable: "fa", sound: "4.mp3", number: 4, color: .green),
            Note(name: "G", syllable: "sol", sound: "5.mp3", number: 5, color: .blue),
            Note(name: "A", syllable: "la", sound: "6.mp3", number: 6, color: .indigo),
            Note(name: "B", syllable: "si", sound: "7.mp3", number: 7, color: .purple),
            Note(name: "C2", syllable: "do", sound: "8.mp3", number: 8, color: .red),
            Note(name: "D2", syllable: "re", sound: "9.mp3", number: 9, color: .orange),
            Note(name: "E2", syllable: "mi", sound: "0.mp3", number: 0, color: .yellow)
        ]
    }
}



